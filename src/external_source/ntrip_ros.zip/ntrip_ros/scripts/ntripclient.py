#!/usr/bin/python

import rospy

#from nmea_msgs.msg import Sentence
from rtcm_msgs.msg import Message

from http.client import HTTPConnection
from base64 import b64encode
from threading import Thread

class ntripconnect(Thread):
    def __init__(self, ntc):
        super(ntripconnect, self).__init__()
        self.ntc = ntc
        self.stop = False

    def run(self):
        info_str = self.ntc.ntrip_user + ':' + self.ntc.ntrip_pass
        # headers = {
        #     'Ntrip-Version': 'Ntrip/1.0',
        #     'User-Agent': 'NTRIP ntrip_ros',
        #     'Connection': 'close',
        #     'Authorization': 'Basic %s' % b64encode(info_str.encode())
        # }
        print(str(b64encode(info_str.encode()),'utf-8'))

        headers = {
            'Ntrip-Version': 'Ntrip/2.0',
            'User-Agent': 'NTRIP Jun',
            'Connection': 'close',
            'Authorization': 'Basic %s' % str(b64encode(info_str.encode()),'utf-8')
        }
        print(headers,'\n')

        connection = HTTPConnection(self.ntc.ntrip_server, self.ntc.ntrip_port)
        print('HTTPConnection: ', connection,'\n')

        # connection.request('GET', '/'+self.ntc.ntrip_stream, self.ntc.nmea_gga, headers)
        connection.request('GET', '/'+self.ntc.ntrip_stream, self.ntc.nmea_gga, headers)
        print('request: ', connection,'\n')
        
        response = connection.getresponse()
        print('response: ', response,'\n')

        if response.status != 200: raise Exception("blah")
        buf = ""
        buf = buf.encode()
        rmsg = Message()
        while not self.stop:
            data = response.read(100)
            info_str = '\r\n'
            pos = data.find(info_str.encode())
            if pos != -1:
                print('buf[', type(buf),']: ', buf)
                # print('data[', type(data),']: ', data)
                rmsg.message = buf + data[:pos]
                rmsg.header.seq += 1
                rmsg.header.stamp = rospy.get_rostime()
                buf = data[pos+2:]
                self.ntc.pub.publish(rmsg)
            else: buf += data
        
        connection.close()

class ntripclient:
    def __init__(self):
        rospy.init_node('ntripclient', anonymous=True)

        self.rtcm_topic = rospy.get_param('~rtcm_topic', 'rtcm')
        self.nmea_topic = rospy.get_param('~nmea_topic', 'nmea')

        info_str = 'fkp.ngii.go.kr'
        self.ntrip_server = rospy.get_param('~ntrip_server', info_str)
        self.ntrip_port = rospy.get_param('~ntrip_port', '2201')
        self.ntrip_user = rospy.get_param('~ntrip_user', 'd214pharos')
        self.ntrip_pass = rospy.get_param('~ntrip_pass', 'ngii')
        info_str = 'VRS_V32'  
        self.ntrip_stream = rospy.get_param('~ntrip_stream', info_str)
        info_str = '$GPGGA,114455.532,3735.0079,N,12701.6446,E,1,03,7.9,48.8,M,19.6,M,0.0,0000*48'
        self.nmea_gga = rospy.get_param('~nmea_gga', info_str)

        self.pub = rospy.Publisher(self.rtcm_topic, Message, queue_size=10)

        self.connection = None
        self.connection = ntripconnect(self)
        self.connection.start()

    def run(self):
        rospy.spin()
        if self.connection is not None:
            self.connection.stop = True

if __name__ == '__main__':
    c = ntripclient()
    c.run()

