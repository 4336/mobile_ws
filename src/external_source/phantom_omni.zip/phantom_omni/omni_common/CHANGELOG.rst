^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_common
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------

0.1.0 (2013-10-28)
------------------
* Initial release
