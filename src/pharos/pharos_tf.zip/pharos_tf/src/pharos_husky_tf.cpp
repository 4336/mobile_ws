#include "ros/ros.h"
#include <Eigen/Geometry>
#include <tf/transform_broadcaster.h>

#include <sensor_msgs/PointCloud2.h>
#include <nav_msgs/Odometry.h>
#include <visualization_msgs/MarkerArray.h>


#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_types.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl/conversions.h>
#include <pcl_ros/transforms.h>
#include <pcl_ros/point_cloud.h> 

ros::Subscriber sub;
ros::Subscriber sub3;
ros::Subscriber sub_ekf_odom_;
ros::Publisher pub;
ros::Publisher pub_odom_slam_;

tf::StampedTransform slam2rover_;
bool slam2rover_init_ = false;

typedef struct tf_param_{
	std::string frame_id;
	std::string child_frame_id;
	float x;
	float y;
	float z;
	float roll;
	float pitch;
	float yaw;
	tf::Transform transform;
}tf_param_;

ros::Time bag_stamp;
int publish_rate_;

int cnt_ = 0;

int tf_num_;
int tf_num_after_init_;

void WheelMarkerInit(visualization_msgs::MarkerArray *Array){
    visualization_msgs::Marker marker;

    marker.header.stamp = ros::Time();
    marker.ns = "wheel";
    marker.type = visualization_msgs::Marker::MESH_RESOURCE;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.orientation.w = 1;
    marker.scale.x = 1;
    marker.scale.y = 1;
    marker.scale.z = 1;
    marker.color.a = 1.0; // Don't forget to set the alpha!
    marker.color.r = 0.25;
    marker.color.g = 0.25;
    marker.color.b = 0.25;
    //only if using a MESH_RESOURCE marker type:
    marker.mesh_resource = "package://pharos_tf/meshes/wheel.dae";

    for(int i=0; i<4; i++){
        Array->markers.push_back(marker);
        Array->markers[i].id = i+1;
    }
    Array->markers[0].header.frame_id = "FL";
    Array->markers[1].header.frame_id = "FR";
    Array->markers[2].header.frame_id = "RL";
    Array->markers[3].header.frame_id = "RR";
}

void VehicleMarkerInit(visualization_msgs::MarkerArray *Array){
	static visualization_msgs::Marker marker;

	marker.header.stamp = ros::Time();
	marker.ns = "rover";
	marker.header.frame_id = "rover";
	marker.type = visualization_msgs::Marker::MESH_RESOURCE;
	marker.action = visualization_msgs::Marker::ADD;
	// marker.pose.orientation.z = 0.7071068;	// yaw 90
	// marker.pose.orientation.w = 0.7071068;
	marker.pose.position.z = 0.15;
	marker.pose.orientation.z = 0.0;	// yaw 90
	marker.pose.orientation.w = 1;
	marker.scale.x = 1;
	marker.scale.y = 1;
	marker.scale.z = 1;
	marker.color.a = 1; // Don't forget to set the alpha!
	marker.color.r = 0.1;
	marker.color.g = 0.1;
	marker.color.b = 0.1;
	//only if using a MESH_RESOURCE marker type:
	marker.mesh_resource = "package://pharos_tf/meshes/base_link.dae";

	Array->markers.push_back(marker);
	Array->markers[4].id = 5;
}

void TopFrameMarkerInit(visualization_msgs::MarkerArray *Array){
	static visualization_msgs::Marker marker;

	marker.header.stamp = ros::Time();
	marker.ns = "rover";
	marker.header.frame_id = "rover";
	marker.type = visualization_msgs::Marker::MESH_RESOURCE;
	marker.action = visualization_msgs::Marker::ADD;
	// marker.pose.orientation.z = 0.7071068;	// yaw 90
	// marker.pose.orientation.w = 0.7071068;
	marker.pose.position.z = 0.15;
	marker.pose.orientation.z = 0.0;	// yaw 90
	marker.pose.orientation.w = 1;
	marker.scale.x = 1;
	marker.scale.y = 1;
	marker.scale.z = 1;
	marker.color.a = 1; // Don't forget to set the alpha!
	marker.color.r = 0.8;
	marker.color.g = 0.8;
	marker.color.b = 0.2;
	//only if using a MESH_RESOURCE marker type:
	marker.mesh_resource = "package://pharos_tf/meshes/top_chassis.dae";

	Array->markers.push_back(marker);
	Array->markers[5].id = 6;
}

void RailFrameMarkerInit(visualization_msgs::MarkerArray *Array){
	static visualization_msgs::Marker marker;

	marker.header.stamp = ros::Time();
	marker.ns = "rover";
	marker.header.frame_id = "rover";
	marker.type = visualization_msgs::Marker::MESH_RESOURCE;
	marker.action = visualization_msgs::Marker::ADD;
	// marker.pose.orientation.z = 0.7071068;	// yaw 90
	// marker.pose.orientation.w = 0.7071068;
	marker.pose.position.x = 0.28;
	marker.pose.position.z = 0.39;
	marker.pose.orientation.z = 0.0;	// yaw 90
	marker.pose.orientation.w = 1;
	marker.scale.x = 1;
	marker.scale.y = 1;
	marker.scale.z = 1;
	marker.color.a = 1; // Don't forget to set the alpha!
	marker.color.r = 0.1;
	marker.color.g = 0.1;
	marker.color.b = 0.1;
	//only if using a MESH_RESOURCE marker type:
	marker.mesh_resource = "package://pharos_tf/meshes/user_rail.dae";

	Array->markers.push_back(marker);
	Array->markers[6].id = 7;
}

void BumberMarkerInit(visualization_msgs::MarkerArray *Array){
	static visualization_msgs::Marker marker;

	marker.header.stamp = ros::Time();
	marker.ns = "rover";
	marker.header.frame_id = "rover";
	marker.type = visualization_msgs::Marker::MESH_RESOURCE;
	marker.action = visualization_msgs::Marker::ADD;
	// marker.pose.orientation.z = 0.7071068;	// yaw 90
	// marker.pose.orientation.w = 0.7071068;
	marker.pose.position.x = 0.48;
	marker.pose.position.z = 0.25;
	marker.pose.orientation.z = 0.0;	// yaw 90
	marker.pose.orientation.w = 1;
	marker.scale.x = 1;
	marker.scale.y = 1;
	marker.scale.z = 1;
	marker.color.a = 1; // Don't forget to set the alpha!
	marker.color.r = 0.1;
	marker.color.g = 0.1;
	marker.color.b = 0.1;
	//only if using a MESH_RESOURCE marker type:
	marker.mesh_resource = "package://pharos_tf/meshes/bumper.dae";

	Array->markers.push_back(marker);
	Array->markers[7].id = 8;
}

void Odometry2TF(tf::TransformBroadcaster &br, const nav_msgs::OdometryConstPtr &Odom){

	tf::Transform transform;
	transform.setOrigin( tf::Vector3(Odom->pose.pose.position.x, Odom->pose.pose.position.y, Odom->pose.pose.position.z) );

	tf::Quaternion quat;
	quat.setX(Odom->pose.pose.orientation.x);
	quat.setY(Odom->pose.pose.orientation.y);
	quat.setZ(Odom->pose.pose.orientation.z);
	quat.setW(Odom->pose.pose.orientation.w);
	transform.setRotation(quat);

	br.sendTransform(tf::StampedTransform(transform, Odom->header.stamp, Odom->header.frame_id, Odom->child_frame_id));
	// std::cout<<Odom->child_frame_id<<std::endl;
}

geometry_msgs::Quaternion euler_to_quaternion(float roll, float pitch, float yaw){
	geometry_msgs::Quaternion Q;

    Q.x = sin(roll/2) * cos(pitch/2) * cos(yaw/2) - cos(roll/2) * sin(pitch/2) * sin(yaw/2);
    Q.y = cos(roll/2) * sin(pitch/2) * cos(yaw/2) + sin(roll/2) * cos(pitch/2) * sin(yaw/2);
    Q.z = cos(roll/2) * cos(pitch/2) * sin(yaw/2) - sin(roll/2) * sin(pitch/2) * cos(yaw/2);
    Q.w = cos(roll/2) * cos(pitch/2) * cos(yaw/2) + sin(roll/2) * sin(pitch/2) * sin(yaw/2);

    return Q;
}

void Odometry2Footprint(tf::TransformBroadcaster &br, const nav_msgs::OdometryConstPtr &Odom){

	tf_num_ = tf_num_after_init_;

	Odometry2TF(br, Odom);

    nav_msgs::Odometry Odom_haptic_field = *Odom;
    Odom_haptic_field.child_frame_id = "rover";

	tf::Transform transform;
	transform.setOrigin( tf::Vector3(Odom_haptic_field.pose.pose.position.x, Odom_haptic_field.pose.pose.position.y, Odom_haptic_field.pose.pose.position.z) );

	tf::Quaternion quat;
	quat.setX(Odom_haptic_field.pose.pose.orientation.x);
	quat.setY(Odom_haptic_field.pose.pose.orientation.y);
	quat.setZ(Odom_haptic_field.pose.pose.orientation.z);
	quat.setW(Odom_haptic_field.pose.pose.orientation.w);
	transform.setRotation(quat);

	br.sendTransform(tf::StampedTransform(transform, Odom_haptic_field.header.stamp, Odom_haptic_field.header.frame_id, Odom_haptic_field.child_frame_id));
	// std::cout<<Odom->child_frame_id<<std::endl;


/////////////////

    Odom_haptic_field.child_frame_id = "haptic_field"; // z to zero

	tf::Quaternion q(
        Odom->pose.pose.orientation.x,
        Odom->pose.pose.orientation.y,
        Odom->pose.pose.orientation.z,
        Odom->pose.pose.orientation.w);
    tf::Matrix3x3 m(q);
    double roll, pitch, yaw;
    m.getRPY(roll, pitch, yaw);

    Odom_haptic_field.pose.pose.position.z = 0;
    Odom_haptic_field.pose.pose.orientation = euler_to_quaternion(0, 0, yaw);

	transform.setOrigin( tf::Vector3(Odom_haptic_field.pose.pose.position.x, Odom_haptic_field.pose.pose.position.y, Odom_haptic_field.pose.pose.position.z) );

	quat.setX(Odom_haptic_field.pose.pose.orientation.x);
	quat.setY(Odom_haptic_field.pose.pose.orientation.y);
	quat.setZ(Odom_haptic_field.pose.pose.orientation.z);
	quat.setW(Odom_haptic_field.pose.pose.orientation.w);
	transform.setRotation(quat);

	br.sendTransform(tf::StampedTransform(transform, Odom_haptic_field.header.stamp, Odom_haptic_field.header.frame_id, Odom_haptic_field.child_frame_id));
	// std::cout<<Odom->child_frame_id<<std::endl;

}


void UpdateTF(struct tf_param_ &tf_param){
	tf_param.transform.setOrigin(tf::Vector3(tf_param.x, tf_param.y, tf_param.z));
	tf::Quaternion tf_RM;
	tf_RM.setRPY(tf_param.roll * M_PI/180, tf_param.pitch * M_PI/180, tf_param.yaw * M_PI/180);
	tf_param.transform.setRotation(tf_RM);
}

void Callback(const sensor_msgs::PointCloud2::ConstPtr& msg){
	bag_stamp = msg->header.stamp;
}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "pharos_husky_tf");

	ros::NodeHandle nh;
	ros::NodeHandle pnh("~");

	bool bag_;
	pnh.param("bag", bag_, false);

	int rate_;
	pnh.param("publish_rate", publish_rate_, 100);
	ros::Rate loop_rate(publish_rate_);

	pnh.getParam("tf_num_init", tf_num_);
	pnh.getParam("tf_num", tf_num_after_init_);
	tf_param_ *tf_param = new tf_param_[tf_num_];

	tf_param_ tf_0;

	static tf::TransformBroadcaster br;

	sub = nh.subscribe("velodyne_points", 1, Callback);
	sub3 = nh.subscribe<nav_msgs::Odometry>("odom/start_point", 1,
 		boost::bind(&Odometry2TF, boost::ref(br), _1));
	sub_ekf_odom_ = nh.subscribe<nav_msgs::Odometry>("/odom/slam_ekf", 1, 
		boost::bind(&Odometry2Footprint, boost::ref(br), _1));

	pub = nh.advertise<visualization_msgs::MarkerArray>("rover/marker", 1);
	pub_odom_slam_ = nh.advertise<nav_msgs::Odometry>("/odom/slam", 1);

	for(int i=0; i<tf_num_; i++){
		//loading tf_config.yaml
		std::stringstream tf_name;
		tf_name << "tf_" << i+1;
		pnh.getParam(tf_name.str()+"/frame_id", tf_param[i].frame_id);
		pnh.getParam(tf_name.str()+"/child_frame_id", tf_param[i].child_frame_id);
		pnh.getParam(tf_name.str()+"/x", tf_param[i].x);
		pnh.getParam(tf_name.str()+"/y", tf_param[i].y);
		pnh.getParam(tf_name.str()+"/z", tf_param[i].z);
		pnh.getParam(tf_name.str()+"/roll", tf_param[i].roll);
		pnh.getParam(tf_name.str()+"/pitch", tf_param[i].pitch);
		pnh.getParam(tf_name.str()+"/yaw", tf_param[i].yaw);

		UpdateTF(tf_param[i]);
	}

	visualization_msgs::MarkerArray rover_marker;
	WheelMarkerInit(&rover_marker);
	VehicleMarkerInit(&rover_marker);
	TopFrameMarkerInit(&rover_marker);
	RailFrameMarkerInit(&rover_marker);
	BumberMarkerInit(&rover_marker);


	ros::Time stamp;

	int count = 0;
	while (ros::ok())
	{
		if(bag_) stamp = bag_stamp;
		else stamp = ros::Time::now();

		// Publish fixed tf
		for(int i=0; i<tf_num_; i++){
			br.sendTransform(tf::StampedTransform(tf_param[i].transform, stamp, tf_param[i].frame_id, tf_param[i].child_frame_id));
		}

		pub.publish(rover_marker);

		ros::spinOnce();

		loop_rate.sleep();
		++count;
	}

	return 0;
}