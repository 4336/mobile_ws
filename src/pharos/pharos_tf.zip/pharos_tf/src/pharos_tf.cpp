#include "ros/ros.h"
#include <Eigen/Geometry>
#include <tf/transform_broadcaster.h>

#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/Odometry.h>
#include <visualization_msgs/MarkerArray.h>

ros::Subscriber sub;
ros::Subscriber sub2;
ros::Subscriber sub3;
ros::Publisher pub;

typedef struct tf_param_{
	std::string frame_id;
	std::string child_frame_id;
	float x;
	float y;
	float z;
	float roll;
	float pitch;
	float yaw;
	tf::Transform transform;
}tf_param_;

ros::Time bag_stamp;
int publish_rate_;



void VehicleMarkerInit(visualization_msgs::MarkerArray *Array){
	static visualization_msgs::Marker marker;

	marker.header.stamp = ros::Time();
	marker.id = 1;
	marker.ns = "rover";
	marker.header.frame_id = "rover";
	marker.type = visualization_msgs::Marker::MESH_RESOURCE;
	marker.action = visualization_msgs::Marker::ADD;
	// marker.pose.orientation.z = 0.7071068;	// yaw 90
	// marker.pose.orientation.w = 0.7071068;
	marker.pose.orientation.z = 0.0;	// yaw 90
	marker.pose.orientation.w = 1;
	marker.scale.x = 0.001;
	marker.scale.y = 0.001;
	marker.scale.z = 0.001;
	marker.color.a = 0.8; // Don't forget to set the alpha!
	marker.color.r = 0.8;
	marker.color.g = 0.8;
	marker.color.b = 0.8;
	//only if using a MESH_RESOURCE marker type:
	marker.mesh_resource = "package://pharos_tf/config/MobileRobot.stl";

	Array->markers.push_back(marker);
	Array->markers[0].id = 1;
}

void Odometry2TF(tf::TransformBroadcaster &br, const nav_msgs::OdometryConstPtr &Odom){

	tf::Transform transform;
	transform.setOrigin( tf::Vector3(Odom->pose.pose.position.x, Odom->pose.pose.position.y, Odom->pose.pose.position.z) );

	tf::Quaternion quat;
	quat.setX(Odom->pose.pose.orientation.x);
	quat.setY(Odom->pose.pose.orientation.y);
	quat.setZ(Odom->pose.pose.orientation.z);
	quat.setW(Odom->pose.pose.orientation.w);
	transform.setRotation(quat);

	br.sendTransform(tf::StampedTransform(transform, Odom->header.stamp, Odom->header.frame_id, Odom->child_frame_id));
	// std::cout<<Odom->child_frame_id<<std::endl;
}

void UpdateTF(struct tf_param_ &tf_param){
	tf_param.transform.setOrigin(tf::Vector3(tf_param.x, tf_param.y, tf_param.z));
	tf::Quaternion tf_RM;
	tf_RM.setRPY(tf_param.roll * M_PI/180, tf_param.pitch * M_PI/180, tf_param.yaw * M_PI/180);
	tf_param.transform.setRotation(tf_RM);
}

void Callback(const sensor_msgs::LaserScan::ConstPtr& msg){
	bag_stamp = msg->header.stamp;
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "pharos_tf");

	ros::NodeHandle nh;
	ros::NodeHandle pnh("~");

	bool bag_;
	pnh.param("bag", bag_, false);

	int rate_;
	pnh.param("publish_rate", publish_rate_, 100);
	ros::Rate loop_rate(publish_rate_);

	int tf_num_;
	pnh.getParam("tf_num", tf_num_);
	tf_param_ *tf_param = new tf_param_[tf_num_];

	tf_param_ tf_0;

	static tf::TransformBroadcaster br;

	sub = nh.subscribe("scan", 1, Callback);
	sub2 = nh.subscribe<nav_msgs::Odometry>("odom/rover", 1, 
		boost::bind(&Odometry2TF, boost::ref(br), _1));
	sub3 = nh.subscribe<nav_msgs::Odometry>("odom/start_point", 1, 
		boost::bind(&Odometry2TF, boost::ref(br), _1));
	pub = nh.advertise<visualization_msgs::MarkerArray>("rover/marker", 1);

	for(int i=0; i<tf_num_; i++){
		//loading tf_config.yaml
		std::stringstream tf_name;
		tf_name << "tf_" << i+1;
		pnh.getParam(tf_name.str()+"/frame_id", tf_param[i].frame_id);
		pnh.getParam(tf_name.str()+"/child_frame_id", tf_param[i].child_frame_id);
		pnh.getParam(tf_name.str()+"/x", tf_param[i].x);
		pnh.getParam(tf_name.str()+"/y", tf_param[i].y);
		pnh.getParam(tf_name.str()+"/z", tf_param[i].z);
		pnh.getParam(tf_name.str()+"/roll", tf_param[i].roll);
		pnh.getParam(tf_name.str()+"/pitch", tf_param[i].pitch);
		pnh.getParam(tf_name.str()+"/yaw", tf_param[i].yaw);

		UpdateTF(tf_param[i]);
	}

	visualization_msgs::MarkerArray vehicle_marker;
	VehicleMarkerInit(&vehicle_marker);

	ros::Time stamp;

	int count = 0;
	while (ros::ok())
	{
		if(bag_) stamp = bag_stamp;
		else stamp = ros::Time::now();

		// Publish fixed tf
		for(int i=0; i<tf_num_; i++){
			br.sendTransform(tf::StampedTransform(tf_param[i].transform, stamp, tf_param[i].frame_id, tf_param[i].child_frame_id));
		}

		pub.publish(vehicle_marker);

		ros::spinOnce();

		loop_rate.sleep();
		++count;
	}

	return 0;
}